from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.db import get_db
from app.dependencies import get_current_user, require_roles
from app.models import FinancialRecord, RecordType, User
from app.schemas import FinancialRecordCreate, FinancialRecordResponse, FinancialRecordUpdate

router = APIRouter(prefix="/records", tags=["Financial Records"])


@router.post("", response_model=FinancialRecordResponse, status_code=status.HTTP_201_CREATED)
def create_record(
    payload: FinancialRecordCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin")),
):
    record = FinancialRecord(
        amount=payload.amount,
        type=RecordType(payload.type),
        category=payload.category,
        date=payload.date,
        notes=payload.notes,
        created_by=current_user.id,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("", response_model=list[FinancialRecordResponse])
def list_records(
    record_type: str | None = Query(default=None, alias="type"),
    category: str | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    query = db.query(FinancialRecord)

    if record_type:
        if record_type not in {"income", "expense"}:
            raise HTTPException(status_code=400, detail="type must be income or expense")
        query = query.filter(FinancialRecord.type == RecordType(record_type))

    if category:
        query = query.filter(FinancialRecord.category == category.strip().lower())
    if start_date:
        query = query.filter(FinancialRecord.date >= start_date)
    if end_date:
        query = query.filter(FinancialRecord.date <= end_date)

    return query.order_by(FinancialRecord.date.desc(), FinancialRecord.id.desc()).all()


@router.get("/{record_id}", response_model=FinancialRecordResponse)
def get_record(
    record_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    record = db.query(FinancialRecord).filter(FinancialRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    return record


@router.put("/{record_id}", response_model=FinancialRecordResponse)
def update_record(
    record_id: int,
    payload: FinancialRecordUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    record = db.query(FinancialRecord).filter(FinancialRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")

    updates = payload.model_dump(exclude_unset=True)
    if "type" in updates:
        updates["type"] = RecordType(updates["type"])

    for key, value in updates.items():
        setattr(record, key, value)

    db.commit()
    db.refresh(record)
    return record


@router.delete("/{record_id}")
def delete_record(
    record_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    record = db.query(FinancialRecord).filter(FinancialRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")

    db.delete(record)
    db.commit()
    return {"message": "Record deleted successfully"}
