from collections import defaultdict

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.db import get_db
from app.dependencies import get_current_user
from app.models import FinancialRecord, RecordType, User

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/summary")
def get_summary(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    total_income = db.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
        FinancialRecord.type == RecordType.income
    ).scalar()
    total_expenses = db.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
        FinancialRecord.type == RecordType.expense
    ).scalar()

    return {
        "total_income": round(float(total_income), 2),
        "total_expenses": round(float(total_expenses), 2),
        "net_balance": round(float(total_income) - float(total_expenses), 2),
    }


@router.get("/category-totals")
def get_category_totals(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    rows = (
        db.query(FinancialRecord.category, func.sum(FinancialRecord.amount).label("total"))
        .group_by(FinancialRecord.category)
        .order_by(func.sum(FinancialRecord.amount).desc())
        .all()
    )
    return [{"category": row.category, "total": round(float(row.total), 2)} for row in rows]


@router.get("/recent-activity")
def get_recent_activity(
    limit: int = 5,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    limit = min(max(limit, 1), 20)
    records = db.query(FinancialRecord).order_by(FinancialRecord.date.desc(), FinancialRecord.id.desc()).limit(limit).all()
    return records


@router.get("/monthly-trends")
def get_monthly_trends(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    records = db.query(FinancialRecord).order_by(FinancialRecord.date.asc()).all()

    trends = defaultdict(lambda: {"total_income": 0.0, "total_expense": 0.0})
    for record in records:
        month = record.date.strftime("%Y-%m")
        if record.type == RecordType.income:
            trends[month]["total_income"] += record.amount
        else:
            trends[month]["total_expense"] += record.amount

    return [
        {
            "month": month,
            "total_income": round(values["total_income"], 2),
            "total_expense": round(values["total_expense"], 2),
        }
        for month, values in sorted(trends.items())
    ]
