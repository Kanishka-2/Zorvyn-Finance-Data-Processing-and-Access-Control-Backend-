from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.auth import create_access_token, verify_password
from app.db import Base, engine, get_db
from app.models import User
from app.routes.dashboard import router as dashboard_router
from app.routes.records import router as records_router
from app.routes.users import router as users_router
from app.schemas import LoginRequest, TokenResponse
from app.seed import seed_demo_users

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Finance Data Processing and Access Control Backend",
    version="1.0.0",
    description="Backend assignment using FastAPI, SQLite, JWT auth, and role-based access control.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"message": "Finance backend is running"}


@app.post("/seed")
def seed(db: Session = Depends(get_db)):
    return seed_demo_users(db)


@app.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="User is inactive")

    token = create_access_token({"sub": str(user.id), "role": user.role.value})
    return {"access_token": token, "token_type": "bearer"}


app.include_router(users_router)
app.include_router(records_router)
app.include_router(dashboard_router)
