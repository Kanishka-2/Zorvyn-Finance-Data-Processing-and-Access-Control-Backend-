from sqlalchemy.orm import Session

from app.auth import hash_password
from app.models import User, UserRole


def seed_demo_users(db: Session):
    users = [
        {
            "name": "System Admin",
            "email": "admin@example.com",
            "password": "Admin@123",
            "role": UserRole.admin,
            "is_active": True,
        },
        {
            "name": "Finance Analyst",
            "email": "analyst@example.com",
            "password": "Analyst@123",
            "role": UserRole.analyst,
            "is_active": True,
        },
        {
            "name": "Dashboard Viewer",
            "email": "viewer@example.com",
            "password": "Viewer@123",
            "role": UserRole.viewer,
            "is_active": True,
        },
        {
            "name": "Inactive User",
            "email": "inactive@example.com",
            "password": "Inactive@123",
            "role": UserRole.viewer,
            "is_active": False,
        },
    ]

    created = 0
    for item in users:
        existing = db.query(User).filter(User.email == item["email"]).first()
        if existing:
            continue
        db.add(
            User(
                name=item["name"],
                email=item["email"],
                password_hash=hash_password(item["password"]),
                role=item["role"],
                is_active=item["is_active"],
            )
        )
        created += 1

    db.commit()
    return {"message": "Seed completed", "users_created": created}
