import os
import sys

from fastapi.testclient import TestClient

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.main import app

client = TestClient(app)


def get_token(email: str, password: str):
    client.post("/seed")
    response = client.post("/auth/login", json={"email": email, "password": password})
    return response.json()["access_token"]


def test_root():
    response = client.get("/")
    assert response.status_code == 200


def test_viewer_cannot_create_record():
    token = get_token("viewer@example.com", "Viewer@123")
    response = client.post(
        "/records",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "amount": 100,
            "type": "expense",
            "category": "travel",
            "date": "2026-04-01",
            "notes": "Taxi",
        },
    )
    assert response.status_code == 403


def test_admin_can_create_record_and_summary_available():
    token = get_token("admin@example.com", "Admin@123")
    create_response = client.post(
        "/records",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "amount": 5000,
            "type": "income",
            "category": "salary",
            "date": "2026-04-01",
            "notes": "Monthly salary",
        },
    )
    assert create_response.status_code == 201

    summary_response = client.get(
        "/dashboard/summary",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert summary_response.status_code == 200
    assert "total_income" in summary_response.json()
