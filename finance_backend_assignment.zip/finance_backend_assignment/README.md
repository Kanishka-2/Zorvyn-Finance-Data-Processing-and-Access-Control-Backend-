# Finance Data Processing and Access Control Backend

A backend assignment submission built with **FastAPI + SQLite + SQLAlchemy**.

## What this project covers
- User creation and management
- Role-based access control (`viewer`, `analyst`, `admin`)
- Active/inactive user status handling
- Financial records CRUD
- Filtering by date, category, type
- Dashboard summary APIs
- Input validation and proper error handling
- JWT-based mock authentication for local development
- Seed endpoint to create demo users

## Tech Stack
- FastAPI
- SQLite
- SQLAlchemy ORM
- JWT authentication
- Pydantic validation

## Roles
### Viewer
- Can view financial records
- Can view dashboard summaries
- Cannot create, update, or delete records
- Cannot manage users

### Analyst
- Can view financial records
- Can view dashboard summaries and trends
- Cannot create, update, or delete records
- Cannot manage users

### Admin
- Full access to financial records
- Can manage users
- Can access dashboard summaries

## Assumptions
- This is an assessment-friendly backend and not a production deployment.
- JWT auth is included as a simple local auth mechanism.
- Passwords are hashed.
- Inactive users are blocked from accessing protected endpoints.
- Amount must be greater than 0.
- `type` is limited to `income` or `expense`.

## Project Structure
```
finance_backend_assignment/
│── app/
│   ├── main.py
│   ├── db.py
│   ├── models.py
│   ├── schemas.py
│   ├── auth.py
│   ├── dependencies.py
│   ├── seed.py
│   └── routes/
│       ├── users.py
│       ├── records.py
│       └── dashboard.py
│── tests/
│   └── test_app.py
│── requirements.txt
│── README.md
```

## Setup
```bash
python -m venv venv
source venv/bin/activate   # Linux/macOS
venv\Scripts\activate      # Windows
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Server runs at:
- API: `http://127.0.0.1:8000`
- Swagger docs: `http://127.0.0.1:8000/docs`

## Authentication Flow
1. Run the app.
2. Call `POST /seed` once to create demo users.
3. Use `POST /auth/login` with one of the demo users.
4. Copy the returned access token.
5. Click **Authorize** in Swagger and paste: `Bearer <token>`

## Demo Users Created by `/seed`
- `admin@example.com` / `Admin@123`
- `analyst@example.com` / `Analyst@123`
- `viewer@example.com` / `Viewer@123`
- `inactive@example.com` / `Inactive@123`

## Main APIs
### Auth
- `POST /auth/login` → login and get JWT

### Users
- `POST /users` → create user (admin only)
- `GET /users` → list users (admin only)
- `PATCH /users/{user_id}/status` → activate/deactivate user (admin only)
- `PATCH /users/{user_id}/role` → change role (admin only)

### Financial Records
- `POST /records` → create record (admin only)
- `GET /records` → list/filter records (viewer, analyst, admin)
- `GET /records/{record_id}` → get record (viewer, analyst, admin)
- `PUT /records/{record_id}` → update record (admin only)
- `DELETE /records/{record_id}` → delete record (admin only)

### Dashboard
- `GET /dashboard/summary` → total income, total expense, net balance
- `GET /dashboard/category-totals` → totals grouped by category
- `GET /dashboard/recent-activity` → latest records
- `GET /dashboard/monthly-trends` → month-wise income and expense totals

## Sample Login Request
```json
{
  "email": "admin@example.com",
  "password": "Admin@123"
}
```

## Sample Record Request
```json
{
  "amount": 1200.50,
  "type": "expense",
  "category": "software",
  "date": "2026-04-01",
  "notes": "Annual tool subscription"
}
```

## Why this design
- Clear separation of concerns: routes, models, schemas, auth, db
- Database-backed persistence using SQLite for easy setup
- Middleware-style dependency checks for role enforcement
- Aggregation endpoints demonstrate backend business logic beyond CRUD
- README explains setup, assumptions, and trade-offs clearly

## Possible Future Improvements
- Refresh tokens
- Pagination metadata
- Soft delete
- Audit logs
- More granular permissions
- Docker support
- CI pipeline
